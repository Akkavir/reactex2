var express = require('express');
var app = express();
let scoreTab = [];
let flag =false;
const path = require('path');
const fs = require('fs');
const data = fs.readFileSync('./score.txt',
    { encoding: 'utf8', flag: 'r' });
    scoreTab=JSON.parse(data);
app.use('/', express.static(path.join(__dirname, 'public')))
app.get('/game', function (req, res) {
    let ok =false;
    let score =0;
    if (req.query.game.localeCompare("RA")==0){
        if (!isNaN(req.query.score))
        if (!isNaN(req.query.vcode)){
            if(req.query.verify==((req.query.score+"").length+2*(req.query.vcode+"").length)+17)
                {
                    score= req.query.score;
                    ok=true;
                    scoreTab.push({game:req.query.game,score:req.query.score,vcode:req.query.vcode})
                    flag=true;
                    //console.log(scoreTab.length);
                }
        }
    }
   res.send(ok);
   //console.log(req.query.game+":"+req.query.score+":"+req.query.verify)
})

app.get('/score', function (req, res) {
   res.send(JSON.stringify(scoreTab));
      //console.log(req.query.game+":"+req.query.score+":"+req.query.verify)
})

let timeer = setInterval(()=>{
    if (flag)
    fs.writeFile('./score.txt', JSON.stringify(scoreTab), err => {
        if (err) {
          console.error(err);
        }
        // file written successfully
        flag=false;
      });


},2000);

var server = app.listen(80, function () {
   var host = server.address().address
   var port = server.address().port
   
   console.log("Example app listening at http://%s:%s", host, port)
})
